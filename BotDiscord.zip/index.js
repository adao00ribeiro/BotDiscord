


const BotDiscord = require("./Bot");

const bot = new BotDiscord();
bot.ready();
bot.message();
bot.welcome();
bot.login();
