module.exports = {
    name: 'explicacoes',
    description: 'Salva Tags',
    execute(message){
        
        message.channel.send("toma no cu.......");
    },
    
};