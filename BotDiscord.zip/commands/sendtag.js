module.exports = {
    name: 'tagsasd',
    description: 'Salva Tags',
    execute(message){
        
        message.channel.send("novatag");
    },
    
};