module.exports = {
    name: 'ban',
    description: 'Salva Tags',
    execute(message){
        
        message.channel.send("Em Construção....");
    },
    
};